[UseCommonActorMessageDispatcher]
public class $fileinputname$
{
}