[ActorMessageHandler(typeof($fileinputname$))]
internal static class $fileinputname$MessageHandler
{
    [ActorMessageHandlerMethod(nameof(OnCreate))]
    public static void OnCreate(this $fileinputname$ self)
    {
    }
    
    [ActorMessageHandlerMethod(nameof(OnDestroy))]
    public static void OnDestroy(this $fileinputname$ self)
    {
    }
}